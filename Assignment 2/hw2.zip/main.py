# main.py
import time
import random
import csv
from baseline import NaiveOrderBook
from optimization import OptimizedOrderBook

# Configuration
SIZES = [10, 100, 1_000, 10_000, 20_000] 
# NOTE: Naive is very slow. I capped it at 20k. 
# You can try 100k if you have patience, but 1M will hang Naive.
# The Optimized version can handle 1M easily.

def generate_orders(n):
    orders = []
    for i in range(n):
        side = 'bid' if random.random() < 0.5 else 'ask'
        price = random.uniform(100, 200)
        orders.append({
            'order_id': i,
            'price': round(price, 2),
            'quantity': random.randint(1, 100),
            'side': side
        })
    return orders

def benchmark(cls, n, name):
    orders = generate_orders(n)
    ob = cls()
    
    # 1. Benchmark Insert
    start = time.perf_counter()
    for o in orders:
        ob.add_order(o)
    insert_time = time.perf_counter() - start
    
    # 2. Benchmark Amend (Amend random 10% of orders)
    to_amend = random.sample(orders, max(1, n // 10))
    start = time.perf_counter()
    for o in to_amend:
        ob.amend_order(o['order_id'], o['quantity'] + 1)
    amend_time = time.perf_counter() - start
    
    # 3. Benchmark Delete (Delete random 10% of orders)
    to_delete = random.sample(orders, max(1, n // 10))
    start = time.perf_counter()
    for o in to_delete:
        ob.delete_order(o['order_id'])
    delete_time = time.perf_counter() - start
    
    return {
        'Implementation': name,
        'Size': n,
        'Insert_Time': insert_time,
        'Amend_Time': amend_time,
        'Delete_Time': delete_time
    }

def run_suite():
    results = []
    
    print("Starting Benchmark...")
    print(f"{'Impl':<10} | {'N':<8} | {'Insert (s)':<10} | {'Amend (s)':<10} | {'Delete (s)':<10}")
    
    # Run Naive
    for n in SIZES:
        res = benchmark(NaiveOrderBook, n, "Naive")
        results.append(res)
        print(f"{res['Implementation']:<10} | {res['Size']:<8} | {res['Insert_Time']:<10.4f} | {res['Amend_Time']:<10.4f} | {res['Delete_Time']:<10.4f}")

    # Run Optimized (Can go higher)
    # Adding larger sizes for Optimized to show off scaling
    OPT_SIZES = SIZES + [100_000, 1_000_000]
    for n in OPT_SIZES:
        res = benchmark(OptimizedOrderBook, n, "Optimized")
        results.append(res)
        print(f"{res['Implementation']:<10} | {res['Size']:<8} | {res['Insert_Time']:<10.4f} | {res['Amend_Time']:<10.4f} | {res['Delete_Time']:<10.4f}")

    # Save to CSV
    keys = results[0].keys()
    with open('result.csv', 'w', newline='') as f:
        dict_writer = csv.DictWriter(f, keys)
        dict_writer.writeheader()
        dict_writer.writerows(results)
    print("\nResults saved to result.csv")

if __name__ == "__main__":
    run_suite()