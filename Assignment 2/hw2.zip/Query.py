# Query.py
from baseline import NaiveOrderBook
from optimization import OptimizedOrderBook

def test_book(book_name, book_cls):
    print(f"--- Testing {book_name} ---")
    ob = book_cls()
    
    # 1. Add Orders
    ob.add_order({'order_id': 1, 'price': 100, 'quantity': 10, 'side': 'bid'})
    ob.add_order({'order_id': 2, 'price': 105, 'quantity': 5, 'side': 'bid'}) # Best Bid
    ob.add_order({'order_id': 3, 'price': 110, 'quantity': 20, 'side': 'ask'}) # Best Ask
    ob.add_order({'order_id': 4, 'price': 115, 'quantity': 10, 'side': 'ask'})
    
    # 2. Check Best Bid/Ask
    bb = ob.get_best_bid()
    ba = ob.get_best_ask()
    
    print(f"Best Bid (Expect 105): {bb['price'] if bb else 'None'}")
    print(f"Best Ask (Expect 110): {ba['price'] if ba else 'None'}")
    
    assert bb['price'] == 105
    assert ba['price'] == 110
    
    # 3. Amend Order
    ob.amend_order(2, 50)
    amended = ob.get_order_by_id(2)
    print(f"Amended Qty (Expect 50): {amended['quantity']}")
    assert amended['quantity'] == 50
    
    # 4. Delete Best Bid
    ob.delete_order(2)
    bb_new = ob.get_best_bid()
    print(f"New Best Bid (Expect 100): {bb_new['price'] if bb_new else 'None'}")
    assert bb_new['price'] == 100
    
    print(f"{book_name} Passed Integrity Checks.\n")

if __name__ == "__main__":
    test_book("Naïve", NaiveOrderBook)
    test_book("Optimized", OptimizedOrderBook)