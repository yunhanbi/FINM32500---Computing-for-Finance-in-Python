# baseline.py
import operator

class NaiveOrderBook:
    def __init__(self):
        # Two flat lists, as requested
        self.bids = []
        self.asks = []

    def add_order(self, order):
        """
        Append order and resort.
        order: dict with keys 'order_id', 'price', 'quantity', 'side'
        """
        if order['side'] == 'bid':
            self.bids.append(order)
            # Sort bids descending by price
            self.bids.sort(key=operator.itemgetter('price'), reverse=True)
        else:
            self.asks.append(order)
            # Sort asks ascending by price
            self.asks.sort(key=operator.itemgetter('price'))

    def amend_order(self, order_id, new_quantity):
        """
        Scan lists to find order, update quantity, resort.
        """
        found = False
        # Scan bids
        for order in self.bids:
            if order['order_id'] == order_id:
                order['quantity'] = new_quantity
                found = True
                break
        
        # Scan asks if not found
        if not found:
            for order in self.asks:
                if order['order_id'] == order_id:
                    order['quantity'] = new_quantity
                    found = True
                    break
        
        # Re-sort both lists to be safe (per requirements)
        if found:
            self.bids.sort(key=operator.itemgetter('price'), reverse=True)
            self.asks.sort(key=operator.itemgetter('price'))
            return True
        return False

    def delete_order(self, order_id):
        """
        Scan lists to find order, remove, resort.
        """
        found = False
        # Check bids
        for i, order in enumerate(self.bids):
            if order['order_id'] == order_id:
                self.bids.pop(i)
                found = True
                break
        
        if not found:
            # Check asks
            for i, order in enumerate(self.asks):
                if order['order_id'] == order_id:
                    self.asks.pop(i)
                    found = True
                    break
        
        if found:
            self.bids.sort(key=operator.itemgetter('price'), reverse=True)
            self.asks.sort(key=operator.itemgetter('price'))
            return True
        return False

    def get_order_by_id(self, order_id):
        # Linear scan O(N)
        for order in self.bids + self.asks:
            if order['order_id'] == order_id:
                return order
        return None

    def get_orders_at_price(self, price):
        # Linear scan O(N)
        return [o for o in self.bids + self.asks if o['price'] == price]

    def get_best_bid(self):
        return self.bids[0] if self.bids else None

    def get_best_ask(self):
        return self.asks[0] if self.asks else None