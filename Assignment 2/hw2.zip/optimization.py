# optimization.py
import heapq
from collections import defaultdict

class OptimizedOrderBook:
    def __init__(self):
        # 1. Lookup by ID: O(1)
        self.orders = {} 
        
        # 2. Orders at price level: O(1) lookup
        self.price_levels = defaultdict(list) 
        
        # 3. Heaps for Best Bid/Ask: O(1) access, O(log N) insert
        # Bids: Max-heap (simulated with negative prices)
        self.bids_heap = [] 
        # Asks: Min-heap (default)
        self.asks_heap = [] 

    def add_order(self, order):
        # Store full object
        self.orders[order['order_id']] = order
        
        # Add to price level list
        self.price_levels[order['price']].append(order['order_id'])
        
        # Add to heap
        if order['side'] == 'bid':
            # Store (-price, order_id) for max-heap behavior
            heapq.heappush(self.bids_heap, (-order['price'], order['order_id']))
        else:
            # Store (price, order_id) for min-heap
            heapq.heappush(self.asks_heap, (order['price'], order['order_id']))

    def amend_order(self, order_id, new_quantity):
        if order_id in self.orders:
            order = self.orders[order_id]
            order['quantity'] = new_quantity
            # Note: If price doesn't change, heap remains valid.
            # If price DID change, we would need to treat as delete+add.
            # For this assignment, we assume only quantity changes for simplicity
            # or simply update the reference.
            return True
        return False

    def delete_order(self, order_id):
        # O(1) check and remove from main dict
        if order_id in self.orders:
            order = self.orders[order_id]
            
            # Remove from price levels (Optional: can be expensive O(K), 
            # often skipped in pure lazy implementations, but requested by prompt)
            # We will just remove from the main dict to mark it as "dead".
            del self.orders[order_id]
            
            # We do NOT remove from heap here. That is O(N).
            # We rely on "Lazy Deletion" during get_best_bid/ask.
            return True
        return False

    def get_order_by_id(self, order_id):
        return self.orders.get(order_id)

    def get_orders_at_price(self, price):
        # Retrieve IDs from price_levels, filter out deleted ones
        if price in self.price_levels:
            # Clean up the list while we are reading it? 
            # Or just filter return. Filtering is safer.
            ids = self.price_levels[price]
            valid_orders = []
            for oid in ids:
                if oid in self.orders:
                    valid_orders.append(self.orders[oid])
            return valid_orders
        return []

    def _clean_heap(self, heap, is_bid):
        """
        Removes 'dead' orders from the top of the heap.
        """
        while heap:
            price_val, order_id = heap[0]
            
            # Check if order still exists
            if order_id not in self.orders:
                heapq.heappop(heap) # Remove dead order
                continue

            # Verify consistency (handling cases where price might have changed 
            # if we implemented price amendment later)
            order = self.orders[order_id]
            stored_price = -price_val if is_bid else price_val
            
            if order['price'] != stored_price:
                heapq.heappop(heap) # Stale heap entry
                continue
                
            # If we get here, the top is valid
            break

    def get_best_bid(self):
        self._clean_heap(self.bids_heap, is_bid=True)
        if self.bids_heap:
            _, order_id = self.bids_heap[0]
            return self.orders[order_id]
        return None

    def get_best_ask(self):
        self._clean_heap(self.asks_heap, is_bid=False)
        if self.asks_heap:
            _, order_id = self.asks_heap[0]
            return self.orders[order_id]
        return None